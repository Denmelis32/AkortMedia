const ydbService = require('./src/services/ydb-service');

// Инициализируем YDB при старте функции
let ydbInitialized = false;

module.exports.handler = async (event, context) => {
  console.log('📨 Received request:', JSON.stringify(event, null, 2));

  // Инициализация YDB (только при первом вызове)
  if (!ydbInitialized) {
    try {
      await ydbService.init();
      ydbInitialized = true;
      console.log('✅ YDB initialized successfully');
    } catch (error) {
      console.error('❌ YDB initialization failed:', error);
    }
  }

  // CORS headers
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,Origin,Accept',
    'Access-Control-Allow-Credentials': 'true'
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: headers,
      body: '',
    };
  }

  // Получаем действие из query parameters
  const action = event.queryStringParameters?.action || 'health';
  const method = event.httpMethod;

  console.log(`🔄 Processing action: ${action}, method: ${method}`);

  try {
    // Routes based on action parameter
    if (action === 'health' && method === 'GET') {
      return {
        statusCode: 200,
        headers: headers,
        body: JSON.stringify({
          status: 'OK',
          server: 'Cloud Functions + YDB',
          timestamp: new Date().toISOString(),
          ydb_initialized: ydbInitialized,
          message: 'Сервер работает с Yandex Database! 🚀'
        }),
      };
    }

    if (action === 'getNews' && method === 'GET') {
      let news = [];

      try {
        // Получаем новости из YDB
        news = await ydbService.getNews(20);
        console.log(`✅ Loaded ${news.length} news from YDB`);

        // 🎯 ИСПРАВЛЕННЫЙ ПАРСИНГ ДАННЫХ
        const enrichedNews = news.map((newsItem) => {
          // Парсим JSON поля если они в строковом формате
          const hashtags = typeof newsItem.hashtags === 'string'
            ? JSON.parse(newsItem.hashtags)
            : (newsItem.hashtags || []);

          const user_tags = typeof newsItem.user_tags === 'string'
            ? JSON.parse(newsItem.user_tags)
            : (newsItem.user_tags || {});

          // Форматируем дату
          let createdAt = newsItem.created_at;
          if (createdAt instanceof Date) {
            createdAt = createdAt.toISOString();
          } else if (typeof createdAt === 'number') {
            createdAt = new Date(createdAt).toISOString();
          } else if (!createdAt) {
            createdAt = new Date().toISOString();
          }

          // Форматируем автора
          const authorName = newsItem.author_name || 'Неизвестный автор';
          const authorId = newsItem.author_id || 'unknown';
          const authorAvatar = newsItem.author_avatar || '';

          return {
            id: newsItem.id || `news_${Date.now()}`,
            title: newsItem.title || 'Без названия',
            description: newsItem.description || 'Нет описания',
            content: newsItem.content || newsItem.description || 'Нет содержимого',
            author_id: authorId,
            author_name: authorName,
            author_avatar: authorAvatar,
            likes: Number.isInteger(newsItem.likes) ? newsItem.likes : 0,
            reposts: Number.isInteger(newsItem.reposts) ? newsItem.reposts : 0,
            hashtags: hashtags,
            user_tags: user_tags,
            is_repost: Boolean(newsItem.is_repost),
            is_channel_post: Boolean(newsItem.is_channel_post),
            original_news_id: newsItem.original_news_id || null,
            created_at: createdAt,
            updated_at: newsItem.updated_at ? (
              newsItem.updated_at instanceof Date ?
                newsItem.updated_at.toISOString() :
                new Date(newsItem.updated_at).toISOString()
            ) : createdAt,
            // 🎯 ДОБАВЛЯЕМ ПОЛЯ ДЛЯ FLUTTER
            isLiked: false,
            isBookmarked: false,
            isReposted: false,
            isFollowing: false,
            comments: []
          };
        });

        // Сортируем по дате создания (новые сначала)
        enrichedNews.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        news = enrichedNews;

        console.log('📊 Processed news:', enrichedNews.map(n => ({
          id: n.id,
          title: n.title,
          author: n.author_name,
          likes: n.likes
        })));

      } catch (dbError) {
        console.error('❌ YDB news load failed, using mock data:', dbError);
        // Fallback to mock data
        news = getMockNews();
      }

      return {
        statusCode: 200,
        headers: headers,
        body: JSON.stringify({
          success: true,
          data: news
        }),
      };
    }

    if (action === 'login' && method === 'POST') {
      const body = JSON.parse(event.body || '{}');

      if (body.email && body.password) {
        try {
          // Поиск пользователя в YDB
          let user = await ydbService.findUserByEmail(body.email);

          if (!user) {
            // Создаем нового пользователя если не найден
            user = {
              id: 'user_' + Date.now(),
              name: body.email.split('@')[0],
              email: body.email,
              password_hash: 'hashed_' + body.password,
              avatar: '',
              created_at: new Date(),
              updated_at: new Date()
            };

            await ydbService.createUser(user);
            console.log('✅ New user created in YDB:', user.id);
          }

          return {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify({
              success: true,
              token: 'mock-jwt-token-for-cloud-functions',
              user: {
                id: user.id,
                name: user.name,
                email: user.email,
                avatar: user.avatar
              }
            }),
          };
        } catch (dbError) {
          console.error('❌ YDB auth error:', dbError);
          return {
            statusCode: 500,
            headers: headers,
            body: JSON.stringify({
              success: false,
              error: 'Database error'
            }),
          };
        }
      } else {
        return {
          statusCode: 400,
          headers: headers,
          body: JSON.stringify({
            success: false,
            error: 'Email and password required'
          }),
        };
      }
    }

    if (action === 'createNews' && method === 'POST') {
      const body = JSON.parse(event.body || '{}');

      try {
        const newsData = {
          id: 'news_' + Date.now(),
          title: body.title,
          description: body.description,
          content: body.content || body.description,
          author_id: body.author_id || 'unknown',
          author_name: body.author_name || 'Пользователь',
          author_avatar: body.author_avatar || '',
          likes: 0,
          reposts: 0,
          hashtags: body.hashtags || [],
          user_tags: body.user_tags || {},
          is_repost: body.is_repost || false,
          is_channel_post: body.is_channel_post || false
        };

        await ydbService.createNews(newsData);

        return {
          statusCode: 201,
          headers: headers,
          body: JSON.stringify({
            success: true,
            message: 'News created successfully in YDB',
            news: {
              ...newsData,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              isLiked: false,
              isBookmarked: false,
              isReposted: false,
              isFollowing: false,
              comments: []
            }
          }),
        };
      } catch (error) {
        console.error('❌ YDB create news error:', error);
        return {
          statusCode: 500,
          headers: headers,
          body: JSON.stringify({
            success: false,
            error: 'Failed to create news: ' + error.message
          }),
        };
      }
    }

    // Default response
    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify({
        success: true,
        message: 'News App Cloud Server with YDB 🚀',
        status: 'OK',
        database: 'Yandex Database (YDB)',
        timestamp: new Date().toISOString(),
        available_actions: [
          'health',
          'getNews',
          'createNews',
          'login'
        ]
      }),
    };

  } catch (error) {
    console.error('❌ Handler error:', error);
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error: ' + error.message
      }),
    };
  }
};

// Mock data fallback
function getMockNews() {
  return [
    {
      id: 'mock-1',
      title: 'Сервер запущен в облаке с YDB! 🎉',
      description: 'Ваш News App сервер успешно работает с Yandex Database',
      author_name: 'Система',
      author_id: 'system',
      author_avatar: '',
      likes: 5,
      reposts: 2,
      comments: [],
      hashtags: ['облако', 'ydb', 'успех'],
      created_at: new Date().toISOString(),
      isLiked: false,
      isBookmarked: false,
      isReposted: false,
      isFollowing: false
    },
    {
      id: 'mock-2',
      title: 'Тестовая новость',
      description: 'Это тестовая новость для демонстрации работы приложения',
      author_name: 'Тестовый пользователь',
      author_id: 'test_user',
      author_avatar: '',
      likes: 3,
      reposts: 1,
      comments: [],
      hashtags: ['тест', 'демо', 'новости'],
      created_at: new Date(Date.now() - 3600000).toISOString(),
      isLiked: false,
      isBookmarked: false,
      isReposted: false,
      isFollowing: false
    }
  ];
}