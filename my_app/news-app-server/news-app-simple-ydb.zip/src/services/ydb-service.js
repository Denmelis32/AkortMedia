const ydbConfig = require('../config/ydb-config');

class YDBService {
  constructor() {
    this.initialized = false;
  }

  async init() {
    if (this.initialized) return;

    try {
      console.log('🔄 Initializing YDB service...');
      await ydbConfig.init();
      this.initialized = true;
      console.log('✅ YDB service initialized');
    } catch (error) {
      console.error('❌ Failed to initialize YDB service:', error);
      throw error;
    }
  }

  async createNews(data) {
    try {
      await this.init();
      const driver = ydbConfig.getDriver();

      const query = `
        UPSERT INTO news (
          id, title, description, content, author_id, author_name,
          author_avatar, likes, reposts, hashtags, user_tags,
          is_repost, is_channel_post, created_at, updated_at
        ) VALUES (
          "${data.id}",
          "${this.escapeString(data.title)}",
          "${this.escapeString(data.description)}",
          "${this.escapeString(data.content || data.description)}",
          "${data.author_id || 'unknown'}",
          "${this.escapeString(data.author_name || 'Пользователь')}",
          "${data.author_avatar || ''}",
          ${data.likes || 0},
          ${data.reposts || 0},
          '${JSON.stringify(data.hashtags || [])}',
          '${JSON.stringify(data.user_tags || {})}',
          ${data.is_repost || false},
          ${data.is_channel_post || false},
          CurrentUtcTimestamp(),
          CurrentUtcTimestamp()
        )
      `;

      console.log('📝 Executing news creation query');

      await driver.tableClient.withSession(async (session) => {
        await session.executeQuery(query);
      });

      console.log('✅ News created successfully in YDB');
      return true;
    } catch (error) {
      console.error('❌ Failed to create news:', error.message);
      throw error;
    }
  }

  async getNews(limit = 20) {
    try {
      await this.init();
      const driver = ydbConfig.getDriver();

      const query = `SELECT * FROM news ORDER BY created_at DESC LIMIT ${limit}`;
      console.log('📤 Loading news from YDB');

      const { resultSets } = await driver.tableClient.withSession(async (session) => {
        return await session.executeQuery(query);
      });

      console.log('🔍 Raw YDB resultSets:', JSON.stringify(resultSets, null, 2));

      const news = this.parseResult(resultSets);
      console.log(`✅ Parsed ${news.length} news from YDB`);

      // 🎯 ДЕТАЛЬНОЕ ЛОГИРОВАНИЕ ДАННЫХ
      news.forEach((item, index) => {
        console.log(`📄 News ${index + 1}:`, {
          id: item.id,
          title: item.title,
          author: item.author_name,
          likes: item.likes,
          hashtags: item.hashtags,
          created_at: item.created_at
        });
      });

      return news;
    } catch (error) {
      console.error('❌ Failed to load news:', error.message);
      return [];
    }
  }

  async findUserByEmail(email) {
    try {
      await this.init();
      const driver = ydbConfig.getDriver();

      const query = `SELECT * FROM users WHERE email = "${this.escapeString(email)}" LIMIT 1`;
      const { resultSets } = await driver.tableClient.withSession(async (session) => {
        return await session.executeQuery(query);
      });

      const users = this.parseResult(resultSets);
      return users[0] || null;
    } catch (error) {
      console.error('❌ Failed to find user:', error.message);
      return null;
    }
  }

  async createUser(userData) {
    try {
      await this.init();
      const driver = ydbConfig.getDriver();

      const query = `
        UPSERT INTO users (
          id, email, name, password_hash, avatar, created_at, updated_at
        ) VALUES (
          "${userData.id}",
          "${this.escapeString(userData.email)}",
          "${this.escapeString(userData.name)}",
          "${this.escapeString(userData.password_hash)}",
          "${userData.avatar || ''}",
          CurrentUtcTimestamp(),
          CurrentUtcTimestamp()
        )
      `;

      await driver.tableClient.withSession(async (session) => {
        await session.executeQuery(query);
      });

      console.log('✅ User created successfully in YDB');
      return true;
    } catch (error) {
      console.error('❌ Failed to create user:', error.message);
      throw error;
    }
  }

  escapeString(str) {
    return String(str).replace(/"/g, '\\"').replace(/'/g, "\\'");
  }

  parseResult(resultSets) {
    if (!resultSets || resultSets.length === 0) {
      console.log('📭 No data in resultSets');
      return [];
    }

    console.log(`🔍 ResultSets structure:`, {
      length: resultSets.length,
      columns: resultSets[0]?.columns?.map(c => c.name) || [],
      rowCount: resultSets[0]?.rows?.length || 0
    });

    const rows = [];
    for (const row of resultSets[0].rows) {
      const obj = {};
      resultSets[0].columns.forEach((column, index) => {
        const value = this.parseValue(row.items[index]);
        obj[column.name] = value;
        // 🎯 ЛОГИРУЕМ КАЖДОЕ ПОЛЕ ДЛЯ ДИАГНОСТИКИ
        if (column.name === 'title' || column.name === 'author_name') {
          console.log(`🔍 Field ${column.name}:`, value);
        }
      });
      rows.push(obj);
    }

    console.log(`✅ Parsed ${rows.length} rows`);
    return rows;
  }

  parseValue(value) {
    if (!value) {
      console.log('🔍 parseValue: null value');
      return null;
    }

    // 🎯 ДЕТАЛЬНОЕ ЛОГИРОВАНИЕ ТИПОВ ДАННЫХ
    console.log('🔍 parseValue input:', {
      type: typeof value,
      value: value,
      keys: Object.keys(value)
    });

    if (value.boolValue !== undefined) {
      const result = value.boolValue;
      console.log('🔍 Parsed Bool:', result);
      return result;
    }
    if (value.int32Value !== undefined) {
      const result = value.int32Value;
      console.log('🔍 Parsed Int32:', result);
      return result;
    }
    if (value.uint32Value !== undefined) {
      const result = value.uint32Value;
      console.log('🔍 Parsed UInt32:', result);
      return result;
    }
    if (value.int64Value !== undefined) {
      const result = Number(value.int64Value);
      console.log('🔍 Parsed Int64:', result);
      return result;
    }
    if (value.uint64Value !== undefined) {
      const result = Number(value.uint64Value);
      console.log('🔍 Parsed UInt64:', result);
      return result;
    }
    if (value.doubleValue !== undefined) {
      const result = value.doubleValue;
      console.log('🔍 Parsed Double:', result);
      return result;
    }
    if (value.textValue) {
      const result = value.textValue;
      console.log('🔍 Parsed Text:', result);
      return result;
    }
    if (value.jsonValue) {
      try {
        const result = JSON.parse(value.jsonValue);
        console.log('🔍 Parsed JSON:', result);
        return result;
      } catch (e) {
        console.log('🔍 JSON parse error, returning raw:', value.jsonValue);
        return value.jsonValue;
      }
    }
    if (value.timestampValue) {
      const result = new Date(Number(value.timestampValue) / 1000);
      console.log('🔍 Parsed Timestamp:', result);
      return result;
    }

    console.log('🔍 Unknown value type, returning null');
    return null;
  }
}

module.exports = new YDBService();